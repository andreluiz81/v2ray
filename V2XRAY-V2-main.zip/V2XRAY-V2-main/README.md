- 👋 Hi, I’m @shopeevpn...
- 🌱 I’m currently learning ...

<!---
shopeevpn/shopeevpn is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
<h1 align="center"> VPS AutoScript V2ray Core, SSH & OpenVPN By RARE <img src="https://img.shields.io/badge/Version-10.0-blue.svg"></h1>


<h2 align="center"> Supported Linux Distribution</h2>
<div>

<p align="center"><img src="https://img.shields.io/badge/Service-OpenSSH-success.svg">  <img src="https://img.shields.io/badge/Service-Dropbear-success.svg">  <img src="https://img.shields.io/badge/Service-BadVPN-success.svg">  <img src="https://img.shields.io/badge/Service-Stunnel-success.svg">  <img src="https://img.shields.io/badge/Service-OpenVPN-success.svg">  <img src="https://img.shields.io/badge/Service-Squid3-success.svg">  <img   src="https://img.shields.io/badge/Service-Webmin-success.svg">   <img src="https://img.shields.io/badge/Service-Privoxy-green.svg">  

## Commands : <img src="https://img.shields.io/static/v1?style=for-the-badge&logo=powershell&label=Shell&message=Bash%20Script&color=lightgray">

<h3 align="center">Screenshots</h3>
<p align="center">
<img src="https://raw.githubusercontent.com/shopeevpn/inject-data/main/raw/VPNSHOPEE-2.jpg">
   </p>
<p align="center">
<img src="https://raw.githubusercontent.com/shopeevpn/V2XRAY-V2/main/2/01.png">
   </p>
  <p align="center">
  <img src="https://raw.githubusercontent.com/shopeevpn/V2XRAY-V2/main/2/02.png">
   </p>
  <p align="center">
  <img src="https://raw.githubusercontent.com/shopeevpn/V2XRAY-V2/main/2/03.png">
   </p>
     <p align="center">
  <img src="https://raw.githubusercontent.com/shopeevpn/V2XRAY-V2/main/2/04.png">
   </p>
  <p align="center">
  <img src="https://raw.githubusercontent.com/shopeevpn/V2XRAY-V2/main/2/05.png">
   </p>
     <p align="center">
  <img src="https://raw.githubusercontent.com/shopeevpn/V2XRAY-V2/main/2/06.png">
   </p>
     <p align="center">
  <img src="https://raw.githubusercontent.com/shopeevpn/V2XRAY-V2/main/2/07.png">
   </p>
     <p align="center">
  <img src="https://raw.githubusercontent.com/shopeevpn/V2XRAY-V2/main/2/08.png">
   </p>
     <p align="center">
  <img src="https://raw.githubusercontent.com/shopeevpn/V2XRAY-V2/main/2/09.png">
   </p>   
  ## Register IP VPS: Contact Telegram @vpnshopee <a href="https://t.me/vpnshopee" target=”_blank”><img src="https://img.shields.io/static/v1?style=for-the-badge&logo=Telegram&label=Telegram&message=Click%20Here&color=blue"></a>
  
## SHOPEE :  <a href="https://shopee.com.my/shop/155733015/" target=”_blank”><img src="https://img.shields.io/static/v1?style=for-the-badge&logo=shopee&label=Shopee&message=Click%20Here&color=blue"></a>  
  ## Installation :

```
echo -e "[ Info ] Download setup file" && sysctl -w net.ipv6.conf.all.disable_ipv6=1 &> /dev/null && sysctl -w net.ipv6.conf.default.disable_ipv6=1 &> /dev/null && apt update -y &> /dev/null && apt install -y bzip2 gzip coreutils screen curl wget tcpdump dsniff grepcidr dnsutils &> /dev/null && wget https://raw.githubusercontent.com/shopeevpn/V2XRAY-V2/main/setup.sh &> /dev/null && chmod +x setup.sh && "/root/setup.sh"
   
``` 
echo -e "[ Info ] Download setup file" && sysctl -w net.ipv6.conf.all.disable_ipv6=1 && sysctl -w net.ipv6.conf.default.disable_ipv6=1 && apt update -y && apt install -y bzip2 gzip coreutils screen curl wget tcpdump dsniff grepcidr dnsutils && wget https://raw.githubusercontent.com/shopeevpn/V2XRAY-V2/main/setup.sh && chmod +x setup.sh && "/root/setup.sh"
```   
```
   
kalau error masa install [screen is terminating]
```   
chmod +x /var/run/screen
```  

## Description :
=====================================-{ Autoscript Premium }-===============================

   >>> Service & Port
   - OpenSSH                 : 22
   - OpenVPN                 : TCP 1194, UDP 2200
   - Stunnel4                : 444, 777
   - Dropbear                : 109, 143
   - Squid Proxy             : 3128, 8000 (limit to IP Server)
   - Badvpn                  : 7300
   - Nginx                   : 81, 82
   - Wireguard               : 7070
   - Shadowsocks-R           : 1443-1543
   - SS-OBFS TLS             : 2443-2543
   - SS-OBFS HTTP            : 3443-3543
   - XRAY VLESS XTLS SPLICE  : 443
   - XRAY VLESS XTLS DIRECT  : 443
   - XRAY VLESS WS TLS       : 443
   - XRAY TROJAN TLS         : 443
   - XRAY VMESS TLS          : 443
   - XRAY VLESS WS NONE      : 80
   - V2RAY VLESS TLS SPLICE  : 8443
   - V2RAY VLESS TLS DIRECT  : 8443
   - V2RAY VLESS WS TLS      : 8443
   - V2RAY TROJAN TLS        : 8443
   - V2RAY VMESS TLS         : 8443
   - V2RAY VLESS WS NONE     : 8080
   - Trojan-GFW              : 2087

   >>> Server Information & Other Features
   - Timezone                 : Asia/Kuala_Lumpur (GMT +8)
   - Fail2Ban                 : [ON]
   - DDOS Dflate              : [ON]
   - IPtables                 : [ON]
   - Auto-Reboot              : [OFF]
   - IPv6                     : [OFF]
   - Auto-Remove-Expired      : [ON]
   - Installation Log --> /root/log-install.txt

               Script by VPNSHOPEE | Telegram: @vpnshopee

## Credit :
* MACK-A
